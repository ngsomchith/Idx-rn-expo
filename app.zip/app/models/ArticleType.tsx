export class ArticleType
 {
  'id'?:string='';
  'date'?:string='';
  'ref'?: string='';
  'name'?: string='';
  'img'?: string='';
  'img2'?: string='';
  'cat'?:string='';
  'pdjType'?:string='';
  'prix'?: number=0;
  'qte'?: number=0;
  'totalLigne'?: number=0;
  'description'?:string='';

  // 'firstImg'?:boolean = true;
  // 'panierId'?:string='';
  // 'dowChaine'?:string='';
  // 'articleType'?:string='';
  // 'prix-remise'?:string='';
  // 'dayCde'?:string ='yyyymmdd'
  // 'hourCde'?: string='HHhmm' || null

}